function sayHello(){
    var name = document.getElementById("name").value
    var messageElement = document.getElementById("message")
    console.log(name)
    // alert('Hello' + name);
    messageElement.innerHTML = "Hello" + name
}

// const num1 = 5;
// //num1 = 10;
// console.log("num1",num1)

function swapNum(){
    
    var num1 = parseFloat(document.getElementById("num1").value)
    var num2 = parseFloat(document.getElementById("num2").value)

    num1 = num1 + num2
    num2 = num1 - num2
    num1 = num1 - num2

    //setting the values
    document.getElementById("num1").value = num1
    document.getElementById("num2").value = num2


}

num1 = 0;
num2 = 0;
oper = ""


///CALCULATOR////
 
//Declaring the input, operand1 and operator 
let inputValue = '0';
let result = null;
let operator = null;

//resets the entire calculator 
const acPressed = () => {
    console.log("in acPressed") 
    document.getElementById("mainInput").value = ''; // resets display as empty 
    inputValue = '0'; //resets current input to 0 
    result = null; //resets result
    operator = null; //resets the operator 
}

const numberPressed = (num) => {
    console.log("in numberPressed", num)
    inputValue = document.getElementById("mainInput").value
    inputValue = inputValue + num
    document.getElementById("mainInput").value = inputValue; 
}

const decimalPressed = () => {
    console.log("in decimalPressed")
    if(inputValue.indexOf('.') === -1) { //indexOf to check position of where the decimal is. Here it is checking if there's no decimal point yet. 
        inputValue = inputValue + '.' // adds the decimal point 
        document.getElementById("mainInput").value = inputValue; //updates the calc display with the decimal point 
    }
}

const percentagePressed = () => {
    console.log("in percentagePressed")
    inputValue = inputValue / 100; //divides the input value by 100 
    document.getElementById("mainInput").value = inputValue; //updates the calc display with the percentage 
}

const signPressed = () => {
    console.log("in signPressed")
    inputValue = -inputValue;
    document.getElementById("mainInput").value = inputValue; //updates the calc display with the negative sign
}

const operatorPressed = (operatorInput) => {
    console.log("in operatorPressed", operatorInput)
    if(result == null) {
        result = Number(inputValue); //set the result to current number 
    } else {
        switch(operator) {
            case '+':
                result = result + Number(inputValue);
                break;
            case '-':
                result = result - Number(inputValue);
                break;
            case '*':
                result = result * Number(inputValue);
                break;
            case '/':
                if(inputValue != '0'){
                    result / Number(inputValue);
                }
                else{
                    alert("ERROR");
                    return;
                }
                break;
            default:
                return;
            }   
    }
    operator = operatorInput; 
    document.getElementById("mainInput").value = ''; // Clears the display when the operator is pressed
    inputValue = '0';  
}


const equalsPressed = () => {
    console.log("in equalPressed");
    let operand = Number(inputValue);  
    if(operator) {  
        switch(operator) {  
            case '+':
                result = result + operand;  
                break;
            case '-':
                result = result - operand;  
                break;
            case 'X':
                result = result * operand;  
                break;
            case '÷':
                if(operand2 != 0){  
                    result = result / operand; 
                }
                else{  
                    alert("ERROR");  
                    return;  
                }
                break;
            default:
                return;  
        }
        console.log("After calculated", result);
        document.getElementById("mainInput").value = result;

    }
} 


const buttons = {
    addButton1: 0,
    addButton2: 0,
    addButton3: 0,
};

function toggleAddRemove(buttonId) {
    const button = document.getElementById(buttonId);
    const countElement = document.getElementById('count');

    if (button.classList.contains('added')) {
        button.textContent = `Add`;
        button.classList.remove('added');
        buttons[buttonId]--;

    } else {
        button.textContent = `Remove`;
        button.classList.add('added');
        buttons[buttonId]++;
    }

    let totalCount = 0;
    for (const key in buttons) {
        totalCount += buttons[key];
    }

    countElement.textContent = totalCount;
}

// document.addEventListener('DOMContentLoaded', function () {
//     const toggleButtons = document.querySelectorAll('.toggle-button');
//     const checkboxes = document.querySelectorAll('.btn-check');

//     toggleButtons.forEach(function (toggleButton, index) {
//         toggleButton.addEventListener('click', function () {
//             if (checkboxes[index].checked) {
//                 // var data = {"image":'../static/images/iphone.jpg',
//                 //             "title":"$999",
//                 //             "descr":"iPhone 15 Pro",
//                 //             "selected":"",
//                 //             "price":999.00};
//                 // fetch('/submit', { 
//                 //     method: 'POST', 
//                 //     headers: { 'Content-Type': 'application/json' }, 
//                 //     body: JSON.stringify(data) // 将数据转换为 JSON 字符串 }) .then(function(response) { return response.json(); // 解析响应的 JSON 数据 }) .then(function(data) { console.log(data); // 处理后端返回的数据 }) .catch(function(error) { console.error('发生错误:', error); });
//                 checkboxes[index].checked = false;
//                 toggleButton.textContent = 'Add';
//                 toggleButton.classList.remove('btn-danger');
//                 toggleButton.classList.add('btn-primary');
//             } else {
//                 checkboxes[index].checked = true;
//                 toggleButton.textContent = 'Remove';
//                 toggleButton.classList.remove('btn-primary');
//                 toggleButton.classList.add('btn-danger');
//             }
//             console.log('item.selected:', checkboxes[index].checked);
//         });
//     });
// });

midterm_items = []
midterm_items.push({"id": '1',"image":'../static/images/iphone.jpg',"title":"$999","descr":"iPhone 15 Pro","selected":"","price":999.00})
midterm_items.push({"id": '2',"image":'../static/images/macbook.jpg',"title":"$1399","descr":"13‑inch MacBook Pro - Space Gray","selected":"","price":1399.00})
midterm_items.push({"id": '3',"image":'../static/images/iwatch.jpg',"title":"$399","descr":"Apple Watch Series 9","selected":"","price":399.00})

function handleOnClick(index){
    var data = {};
    for(let item of midterm_items) {
        if (item["id"] == index) {
            data = item;
        }
    }

    console.log(data);

    fetch('/addToCart', {
        method: 'POST',
        headers: {
            'Content-Type': 'appication/json'
        },
        body: JSON.stringify(data)
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        console.log(data);
    })

}