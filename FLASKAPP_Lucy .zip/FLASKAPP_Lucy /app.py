from fileinput import filename
from multiprocessing import connection
from flask import Flask, render_template, request,redirect,url_for,flash, send_from_directory
import requests
import json
# from models import User
from werkzeug.utils import secure_filename
#from db import SqlLiteDB
import os
import csv
from flask_toastr import Toastr
#from dateutil import parser
from openpyxl import Workbook, load_workbook  #pip install openpyxl
#from db1 import OracleDB
from database import OracleDB
from datetime import datetime



app = Flask(__name__)
db = OracleDB()

app.config['UPLOAD_FOLDER']='uploads'
app.config['REPORT_FOLDER']='reports'

#must be complicated in real life application
app.config['SECRET_KEY'] = 'the random string' 

app.config['SQLALCHEMY_DATABASE_URI'] = f'oracle+oracledb://{db.db_username}:{db.db_password}@{db.remote_address}:{db.local_port}/{db.SID}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

toastr = Toastr(app)

@app.route("/", methods=["Get", "POST"])
def sales_data():
 
    # 上传文件 存入database的步骤
    if request.method =='POST':
        file = request.files['datafile']

        if file:
            filename=secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'],filename)
            file.save(file_path)

            data=[]
            with open(file_path) as file_object:
                reader_obj = csv.reader(file_object)

                next(reader_obj)

                for row in reader_obj:
                    data.append(row)
        
        if data:
            with OracleDB().get_connection() as connection:
                insert_statement = '''
                    INSERT INTO AP_Monthly_testing
                            (MOBILE_NUMBER,
                             CHECK_TIME,
                             ORDER_TIME,
                             ACTIVATE_TIME,
                             STATUS,
                             CHANNEL,
                             NUM_PROVINCE,
                             NUM_CITY,
                             IS_FIFTY,
                             IS_HUNDRED)

                             
                    VALUES (:Mobile_number,
                            to_date(:CHECK_TIME, 'mm/dd/yy'),
                            to_date(:ORDER_TIME, 'mm/dd/yy'),
                            to_date(:ACTIVATE_TIME, 'mm/dd/yy'),
                            :STATUS,
                            :CHANNEL,
                            :NUM_PROVINCE,
                            :NUM_CITY,
                            :IS_FIFTY,
                            :IS_HUNDRED) 
                
                '''
            cursor = connection.cursor()
            cursor.executemany(insert_statement, data)
            connection.commit()

    #GET
    with OracleDB().get_connection() as connection: 
        query ='''   
                select data_pk, MOBILE_NUMBER, to_char(CHECK_TIME, 'YYYY-MM-DD'), 
                       to_char(Order_Time, 'YYYY-MM-DD'), to_char(ACTIVATE_TIME, 'YYYY-MM-DD'), 
                       STATUS, CHANNEL, NUM_PROVINCE, NUM_CITY, IS_FIFTY, IS_HUNDRED
                from AP_Monthly_Testing
        '''
        cursor = connection.cursor()
        cursor.execute(query)
        data= cursor.fetchall()

    return render_template("sales_data.html",data=data)



@app.route("/sales_edit/<id>", methods=["GET", "POST"])
def sales_edit(id):
    if request.method == 'POST':
        MOBILE_NUMBER = request.form.get("MOBILE_NUMBER")
        STATUS = request.form.get("STATUS")
        CHANNEL = request.form.get("CHANNEL")
        NUM_PROVINCE = request.form.get("NUM_PROVINCE")
        NUM_CITY = request.form.get("NUM_CITY")
        IS_FIFTY = request.form.get("IS_FIFTY")
        IS_HUNDRED = request.form.get("IS_HUNDRED")
        
        query = '''
                UPDATE AP_Monthly_Testing
                SET
                    MOBILE_NUMBER = :MOBILE_NUMBER,
                    STATUS = :STATUS,
                    CHANNEL = :CHANNEL,
                    NUM_PROVINCE = :NUM_PROVINCE,
                    NUM_CITY = :NUM_CITY,
                    IS_FIFTY = :IS_FIFTY,
                    IS_HUNDRED = :IS_HUNDRED
                WHERE data_pk = :data_pk
        '''
        with OracleDB().get_connection() as connection:
            cursor = connection.cursor()
            cursor.execute(query, {
                'MOBILE_NUMBER': MOBILE_NUMBER,
                'STATUS': STATUS,
                'CHANNEL': CHANNEL,
                'NUM_PROVINCE': NUM_PROVINCE,
                'NUM_CITY': NUM_CITY,
                'IS_FIFTY': IS_FIFTY,
                'IS_HUNDRED': IS_HUNDRED,
                'data_pk': id
            })
            connection.commit()
            return redirect(url_for("sales_data"))

    with OracleDB().get_connection() as connection:
        query = "SELECT * FROM AP_Monthly_Testing WHERE data_pk = :data_pk"
        cursor = connection.cursor()
        cursor.execute(query, {'data_pk': id})
        data = cursor.fetchone()

    return render_template("sales_edit.html", data=data)





@app.route("/dashboard", methods=["GET"])
def dashboard():
    with OracleDB().get_connection() as connection:
        query1 = ''' 
                SELECT * FROM (
                    SELECT COUNT(*) AS count, num_province AS Province
                    FROM AP_Monthly_testing
                    GROUP BY num_province
                    ORDER BY count DESC
                ) WHERE ROWNUM <= 10
                 '''

        cursor = connection.cursor()
        cursor.execute(query1)
        data1 = cursor.fetchall()

        query2 = ''' 
                SELECT
                    TO_CHAR(CHECK_TIME, 'YYYY-MM-DD') AS check_times,
                    SUM(CASE WHEN STATUS != 1 THEN 1 ELSE 0 END) AS "status=0",
                    SUM(CASE WHEN STATUS = 1 THEN 1 ELSE 0 END) AS "status=1"
                FROM
                    AP_Monthly_Testing
                GROUP BY
                    TO_CHAR(CHECK_TIME, 'YYYY-MM-DD')
                ORDER BY
                    TO_CHAR(CHECK_TIME, 'YYYY-MM-DD')

        '''
        cursor.execute(query2)
        data2 = cursor.fetchall()
        
        query3 = '''
                SELECT
                    check_time,
                    SUM(CASE WHEN channel = 'DaHuangFeng' THEN 1 ELSE 0 END) AS DaHuangFeng,
                    SUM(CASE WHEN channel = 'Longlin' THEN 1 ELSE 0 END) AS Longlin,
                    SUM(CASE WHEN channel NOT IN ('DaHuangFeng', 'Longlin') THEN 1 ELSE 0 END) AS other
                FROM
                    ap_monthly_testing
                GROUP BY
                    check_time 
        '''

        cursor.execute(query3)
        data3 = cursor.fetchall()

        query4 = '''
                SELECT
                    t.num_province,
                    total_count,
                    ROUND(t.normal / total.total_count, 4) AS normal_percentage
                FROM
                    (
                        SELECT
                            num_province,
                            COUNT(*) AS normal
                        FROM
                            Ap_monthly_testing
                        WHERE
                            status = 1 
                        GROUP BY
                            num_province
                    ) t
                RIGHT JOIN
                    (
                        SELECT
                            num_province,
                            COUNT(*) AS total_count
                        FROM
                            Ap_monthly_testing
                        GROUP BY
                            num_province
                        Having
                            COUNT(*) > 500
                    ) total ON t.num_province = total.num_province
                    order by total_count desc
        '''

        cursor.execute(query4)
        data4 = cursor.fetchall()

        query5 = ''' 
                SELECT
                    check_date,
                    MAX(CASE WHEN time_period = 'Less than 7 days' THEN status_1_percentage END) AS "Less than 7 days",
                    MAX(CASE WHEN time_period = 'Less than 30 days' THEN status_1_percentage END) AS "Less than 30 days",
                    MAX(CASE WHEN time_period = 'Less than 60 days' THEN status_1_percentage END) AS "Less than 60 days",
                    MAX(CASE WHEN time_period = 'More than 60 days' THEN status_1_percentage END) AS "More than 60 days"
                FROM (
                    SELECT
                        TO_CHAR(CHECK_TIME, 'YYYY-MM-DD') AS check_date,
                        CASE
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 7 THEN 'Less than 7 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 30 THEN 'Less than 30 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 60 THEN 'Less than 60 days'
                            ELSE 'More than 60 days'
                        END AS time_period,
                        ROUND(AVG(CASE WHEN STATUS = 1 THEN 1 ELSE 0 END), 2) AS status_1_percentage
                    FROM
                        AP_Monthly_Testing
                    GROUP BY
                        TO_CHAR(CHECK_TIME, 'YYYY-MM-DD'),
                        CASE
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 7 THEN 'Less than 7 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 30 THEN 'Less than 30 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 60 THEN 'Less than 60 days'
                            ELSE 'More than 60 days'
                        END
                ) pivoted_data
                GROUP BY
                    check_date
                ORDER BY
                    check_date
        '''

        cursor.execute(query5)
        data5 = cursor.fetchall()

        query6 = ''' 
                SELECT
                    check_date,
                    SUM(CASE WHEN reward = 0 THEN 1 ELSE 0 END) AS reward_0_count,
                    SUM(CASE WHEN reward = 50 THEN 1 ELSE 0 END) AS reward_50_count,
                    SUM(CASE WHEN reward = 100 THEN 1 ELSE 0 END) AS reward_100_count,
                    COUNT(*) AS total_count,
                    round(SUM(CASE WHEN reward = 0 AND status = 1 THEN 1 ELSE 0 END)  / NULLIF(SUM(CASE WHEN reward = 0 THEN 1 ELSE 0 END), 0),2) AS reward0,
                    round(SUM(CASE WHEN reward = 50 AND status = 1 THEN 1 ELSE 0 END)  / NULLIF(SUM(CASE WHEN reward = 50 THEN 1 ELSE 0 END), 0),2) AS reward50,
                    round(SUM(CASE WHEN reward = 100 AND status = 1 THEN 1 ELSE 0 END)  / NULLIF(SUM(CASE WHEN reward = 100 THEN 1 ELSE 0 END), 0),2) AS reward100
                FROM
                    (
                    SELECT
                        TO_CHAR(CHECK_TIME, 'YYYY-MM-DD') AS check_date,
                        CASE
                            WHEN is_fifty = 1 AND is_hundred = 0 THEN 50
                            WHEN is_fifty = 0 AND is_hundred = 1 THEN 100
                            ELSE 0
                        END AS reward,
                        status
                    FROM
                        ap_monthly_testing
                    )  transformed_data
                GROUP BY
                    check_date
        '''
        cursor.execute(query6)
        data6 = cursor.fetchall()

        query7 = '''

                WITH TimePeriods AS (
                    SELECT
                        CASE
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 7 THEN 'Less than 7 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 30 THEN 'Less than 30 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 60 THEN 'Less than 60 days'
                            ELSE 'More than 60 days'
                        END AS time_period,
                        SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS status_1_count,
                        SUM(CASE WHEN is_fifty = 1 AND is_hundred = 0 THEN 1 ELSE 0 END) AS total_reward50_count,
                        SUM(CASE WHEN is_fifty = 0 AND is_hundred = 1 THEN 1 ELSE 0 END) AS total_reward100_count,
                        SUM(CASE WHEN is_fifty = 0 AND is_hundred = 0 THEN 1 ELSE 0 END) AS total_reward0_count,
                        SUM(CASE WHEN is_fifty = 1 AND is_hundred = 0 AND status = 1 THEN 1 ELSE 0 END) AS reward50_status1_count,
                        SUM(CASE WHEN is_fifty = 0 AND is_hundred = 1 AND status = 1 THEN 1 ELSE 0 END) AS reward100_status1_count,
                        SUM(CASE WHEN is_fifty = 0 AND is_hundred = 0 AND status = 1 THEN 1 ELSE 0 END) AS reward0_status1_count,
                        COUNT(*) AS total_count
                    FROM
                        ap_monthly_testing
                    GROUP BY
                        CASE
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 7 THEN 'Less than 7 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 30 THEN 'Less than 30 days'
                            WHEN (CHECK_TIME - ACTIVATE_TIME) < 60 THEN 'Less than 60 days'
                            ELSE 'More than 60 days'
                        END
                ), RewardRates AS (
                    SELECT
                        time_period,
                        ROUND(status_1_count / NULLIF(total_count, 0), 2) AS status_1_percentage,
                        ROUND(reward50_status1_count / NULLIF(total_reward50_count, 0), 2) AS reward50_normal_rate,
                        ROUND(reward100_status1_count / NULLIF(total_reward100_count, 0), 2) AS reward100_normal_rate,
                        ROUND(reward0_status1_count / NULLIF(total_reward0_count, 0), 2) AS reward0_normal_rate
                    FROM
                        TimePeriods
                )
                SELECT
                    time_period,
                    reward0_normal_rate,
                    reward50_normal_rate,
                    reward100_normal_rate,
                    status_1_percentage
                FROM
                    RewardRates
                ORDER BY
                    CASE time_period
                        WHEN 'Less than 7 days' THEN 1
                        WHEN 'Less than 30 days' THEN 2
                        WHEN 'Less than 60 days' THEN 3
                        ELSE 4
                    END
        '''
        cursor.execute(query7)
        data7 = cursor.fetchall()

        query8 = '''
                SELECT 
                    main.activate_mon,
                    main.check_month,
                    round(main.total_records/sub.total_activate,4) as active_percent
                FROM 
                    (SELECT 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY') AS activate_mon, 
                        TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY') AS check_month, 
                        MONTHS_BETWEEN(TO_DATE(TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY'),
                                    TO_DATE(TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY')) AS month_difference,
                        COUNT(*) AS total_records
                    FROM 
                        ap_monthly_testing
                    WHERE 
                        status = 1 
                        AND channel = 'DaHuangFeng'
                    GROUP BY 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY'),
                        TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY')) main
                JOIN 
                    (SELECT 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY') AS activate_month, 
                        COUNT(*) AS total_activate
                    FROM 
                        AP_MONTHLY_TESTING
                    WHERE 
                        channel = 'DaHuangFeng' 
                        AND MONTHS_BETWEEN(TO_DATE(TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY'), 
                                        TO_DATE(TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY')) = 1
                    GROUP BY 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY')) sub
                ON 
                    main.activate_mon = sub.activate_month

        '''

        cursor.execute(query8)
        data8 = cursor.fetchall()

        def sort_key(month):
            return datetime.strptime(month, "%b-%y")

        unique_check_months = set()
        for row in data8:
            unique_check_months.add(row[1])  # Assuming 'check_month' is at index 1 in each tuple
        unique_check_months = sorted(unique_check_months, key=sort_key)

        check_months = set()
        for i in unique_check_months:
            month = datetime.strptime(i, "%b-%y")
            month_date = month.date()
            check_months.add(month_date)

        check_months = sorted(check_months)

        unique_active_months = set()
        for row in data8:
            unique_active_months.add(row[0])  # Assuming 'activate_mon' is at index 0 in each tuple
        unique_active_months = sorted(unique_active_months, key=sort_key)
        

        active_months = set()
        for i in unique_active_months:
            month = datetime.strptime(i, "%b-%y")
            month_date = month.date()
            active_months.add(month_date)

        active_months = sorted(active_months)
        
        for i in check_months:
            print("check_months", i)
        

        zipped_check = zip( check_months, unique_check_months)
        zipped_active=zip(active_months, unique_active_months)
        for active in zipped_active:
            print("active[0]: ", active[0])
            print("active[1]: ", active[1])

        
        for i in data8:
            print(i)


        query9 = '''
                        SELECT 
                    'T' || main.month_difference,
                    round(avg(main.total_records/sub.total_activate),4) as active_percent
                FROM 
                    (SELECT 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY') AS activate_mon, 
                        TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY') AS check_month, 
                        MONTHS_BETWEEN(TO_DATE(TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY'),
                                    TO_DATE(TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY')) AS month_difference,
                        COUNT(*) AS total_records
                    FROM 
                        ap_monthly_testing
                    WHERE 
                        status = 1 
                        AND channel = 'DaHuangFeng'
                    GROUP BY 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY'),
                        TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY')) main
                JOIN 
                    (SELECT 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY') AS activate_month, 
                        COUNT(*) AS total_activate
                    FROM 
                        AP_MONTHLY_TESTING
                    WHERE 
                        channel = 'DaHuangFeng' 
                        AND MONTHS_BETWEEN(TO_DATE(TO_CHAR(TO_DATE(check_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY'), 
                                        TO_DATE(TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY'), 'MON-YY')) = 1
                    GROUP BY 
                        TO_CHAR(TO_DATE(activate_time, 'DD-MON-YY'), 'MON-YY')) sub
                ON 
                    main.activate_mon = sub.activate_month
                group by month_difference
                having month_difference>0
                order by month_difference
        '''
        
        cursor.execute(query9)
        data9 = cursor.fetchall()

    return render_template("dashboard.html", data1 = data1, data2=data2, data3=data3, data4=data4, data5=data5, data6=data6, data7=data7, 
                                             data8 = data8, data9=data9, unique_active_months=unique_active_months, unique_check_months=unique_check_months, check_months=check_months, active_months=active_months,
                                             zipped_check=zipped_check, zipped_active=zipped_active)

@app.route("/sales_download")
def sales_download():
    
    with OracleDB().get_connection() as connection: 
        query ='''
                select * from AP_Monthly_Testing
        '''
        cursor = connection.cursor()
        cursor.execute(query)
        data= cursor.fetchall()    
 
    #building an excel file
    row = 1
    column = 1
    file_name = "monthly_test.xlsx"
    
    wb = Workbook()
    ws = wb.active
    
    #header
    ws.cell(row=row, column=1).value = "OID"
    ws.cell(row=row, column=2).value = "MOBILE_NUMBER"
    ws.cell(row=row, column=3).value = "CHECK_TIME"
    ws.cell(row=row, column=4).value = "ORDER_TIME"
    ws.cell(row=row, column=5).value = "ACTIVATE_TIME"
    ws.cell(row=row, column=6).value = "STATUS"
    ws.cell(row=row, column=7).value = "CHANNEL"
    ws.cell(row=row, column=8).value = "NUM_PROVINCE"
    ws.cell(row=row, column=9).value = "NUM_CITY"
    ws.cell(row=row, column=10).value = "IS_FIFTY"
    ws.cell(row=row, column=11).value = "IS_HUNDRED"

    #go through our data
    row=2
    for each_row in data:
        ws.cell(row=row, column=1).value = each_row[0]
        ws.cell(row=row, column=2).value = each_row[1]
        ws.cell(row=row, column=3).value = each_row[2]
        ws.cell(row=row, column=4).value = each_row[3]
        ws.cell(row=row, column=5).value = each_row[4]
        ws.cell(row=row, column=6).value = each_row[5]
        ws.cell(row=row, column=7).value = each_row[6]    
        ws.cell(row=row, column=8).value = each_row[7]    
        ws.cell(row=row, column=9).value = each_row[8]  
        ws.cell(row=row, column=10).value = each_row[9]    
        ws.cell(row=row, column=11).value = each_row[10]  
         
        row += 1
        
    #saving the excel
    wb.save(app.config['REPORT_FOLDER'] + "/" + file_name)
    
    return send_from_directory(app.config['REPORT_FOLDER'], file_name, as_attachment=True )
 


@app.route("/sales_delete/<id>", methods=["Get", "POST"])
def sales_delete(id):
    data = None

    if request.method == 'GET':
        with OracleDB().get_connection() as connection:
            query = '''
                        select * from AP_Monthly_Testing where data_pk = :data_pk
                    '''
            cursor = connection.cursor()
            cursor.execute(query,(id,))
            data = cursor.fetchone()
            return render_template("sales_delete.html", title="Delete Item", data=data)

    elif request.method =='POST':
        with OracleDB().get_connection() as connection:
            query = '''
                    delete from AP_Monthly_Testing
                    where data_pk = :data_pk
            '''
            cursor = connection.cursor()
            cursor.execute(query,(id,))
            connection.commit()
            return redirect(url_for('sales_data'))


 
if __name__ == "__main__":
    app.run(debug=True)


 