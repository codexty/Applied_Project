import os
import sys
from dotenv import load_dotenv, find_dotenv
#import cx_Oracle
import oracledb
import sshtunnel

class OracleDB(oracledb.Connection): 
    
   
    load_dotenv()
    local_port = int(os.environ.get('local_port'))
    #ssh_username =os.getenv("ssh_username")
    ssh_username = os.environ.get('ssh_username')
    ssh_password = os.environ.get('ssh_password')
    remote_port = int(os.environ.get('remote_port'))
    remote_address = os.environ.get('remote_address')
    SID = os.environ.get('SID')
    db_username = os.environ.get('db_username')
    db_password = os.environ.get('db_password')
    '''
    local_port = 1522
    # Server credentials
    ssh_username = 'tx485'
    ssh_password = 'spsfall2023'
        
    remote_port = 1521
    remote_address = 'localhost'
    SID = 'app12c'
        
    # Database credientials
    db_username = 'MASY_TX485'
    db_password = 'MASY_TX485'
    '''
 
    dsn_tns = oracledb.makedsn(remote_address, local_port, SID)
 
    #create the ssh tunnel handler
    '''
    server = sshtunnel.SSHTunnelForwarder('workshop.sps.nyu.edu',
                                        ssh_username=ssh_username,
                                        ssh_password=ssh_password,
                                        remote_bind_address=(remote_address, remote_port),
                                        local_bind_address=('', local_port))
    '''
 
    def __init__(self):
        #start ssh tunnel
        #self.server.start() 
        super().__init__(user = self.db_username, password = self.db_password, dsn =self.dsn_tns)

    def get_connection(self):
        return self

    #when connection ends - stop ssh tunnel
    def __exit__(self, exc_type, exc_value, traceback):
        #self.server.stop()
        pass

with OracleDB().get_connection() as connection:
    query = """
                select user from dual
                """
    cursor = connection.cursor()
    cursor.execute(query)
    result = cursor.fetchone()
    print(result)
